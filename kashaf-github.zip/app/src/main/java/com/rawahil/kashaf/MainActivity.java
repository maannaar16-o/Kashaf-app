package com.rawahil.kashaf;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * غلاف WebView للكشاف — لا يقرأ إجابة ولا يكتب قيمة ولا يمسّ القياس.
 * كل ما يفعله: يفتح الملف الواحد من الأصول، ويمنع أي ملاحة خارجه.
 */
public class MainActivity extends Activity {

    private static final String PAGE = "file:///android_asset/index.html";
    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(Color.parseColor("#04070d"));
        getWindow().setNavigationBarColor(Color.parseColor("#04070d"));
        // الشاشة تبقى موقدة: رحلة من ٢٨٢ خطوة لا يقطعها إطفاء تلقائي
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);
        applyEdgeToEdge();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // الأداة تخزّن في localStorage
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);                    // يمنع مقاس خط النظام من كسر التخطيط
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(false);

        web.setBackgroundColor(Color.parseColor("#04070d"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);   // يلغي أثر السحب المطاطي
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);           // لا قائمة نسخ فوق نصّ البند

        // سجن الملاحة: لا شيء يُفتح غير الصفحة الواحدة
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !PAGE.equals(r.getUrl().toString());
            }
            @Override
            public void onPageFinished(WebView v, String url) { applyEdgeToEdge(); }
        });

        if (state == null) web.loadUrl(PAGE);
        else web.restoreState(state);
    }

    /** ملء الشاشة الغامر: لا شريط متصفّح ولا أشرطة نظام تنازع المحتوى */
    private void applyEdgeToEdge() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
              | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
              | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
              | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
              | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) applyEdgeToEdge();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    /** الإنذار قبل الإغلاق — إلزامي بقرار مختوم */
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.exit_title)
                .setMessage(R.string.exit_body)
                .setNegativeButton(R.string.exit_stay, (d, w) -> d.dismiss())
                .setPositiveButton(R.string.exit_leave, (d, w) -> finish())
                .setCancelable(true)
                .show();
    }

    @Override protected void onPause()  { super.onPause();  if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
}
